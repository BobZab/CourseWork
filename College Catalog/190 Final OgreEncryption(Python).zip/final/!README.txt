Hello Welcome to Ogre.zip !
This game is a test product and is currently unfinished.
The goal of the game is to make it to the end, through differing
online puzzles.
You begin by reading the first 4 lines of the source code, but please
don't read past that, there are no clues and you may read code that 
could break the sequence of the game.
Glhf!

