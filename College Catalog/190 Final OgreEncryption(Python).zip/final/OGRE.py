#////////////////////////////////////
# to begin your game decrypt: Loqsx dro tyebxoi
#You should not look at the code beyond this point
#////////////////////////////////////

import tkinter as tk
#"pip install pillow" should fix issue if you dont have PIL
from PIL import Image, ImageTk
#youll need to use "pip install caesarcipher" in your shell
from caesarcipher import CaesarCipher
import os
from ctypes import windll
#open tabs
import webbrowser

#list of inputs
attempts = []

GWL_EXSTYLE = -20
WS_EX_APPWINDOW = 0x00040000
WS_EX_TOOLWINDOW = 0x00000080

#force the window to be middle of the screen
def centerWindow(window):
    window.update_idletasks()
    width = window.winfo_width()
    height = window.winfo_height()
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    x = (screen_width // 2) - (width // 2)
    y = (screen_height // 2) - (height // 2)
    window.geometry('{}x{}+{}+{}'.format(width, height, x, y))

def getInput():
    userInput = Input.get()
    attempts.append(userInput)
    print("user input: ", userInput)
    print("Previous Attempts: ", attempts)
    Input.delete(0, tk.END)
    openTab(userInput)

#DO NOT READ CODES, YOU WILL BREAK THE PROGESSION OF THE GAME
def openTab(user_input): #pass the input
    if user_input == "ANALOG OGRE":
        webbrowser.open_new_tab("https://imgur.com/a/soundcloud-com-mrsqlmap-ogresound-swANQza")
    elif user_input == "Delve Deeper":
        webbrowser.open_new_tab("https://www.youtube.com/shorts/Qg0132YROCw")
    elif user_input == "What should you do in a cave?":
        subwindow()
    elif user_input == "Begin the journey":
        webbrowser.open_new_tab("https://www.mediafire.com/file/82dsyr39wyvbzjp/Scholar_Of_Mimikatz.pdf/file")

def subwindow():
    newWindow = tk.Toplevel()
    topNewLabel = tk.Label(newWindow, text="44 65 6C 76 65 20 44 65 65 70 65 72")
    topNewLabel.pack()
        
#Force window to actually appear (very confusing dev forum solution gl reading it)
def setAppwindow(root):
    try:
        hwnd = windll.user32.GetParent(root.winfo_id())  # Corrected function name
        style = windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)  # Corrected function name
        style = style & ~WS_EX_TOOLWINDOW  # Remove TOOLWINDOW style
        style = style | WS_EX_APPWINDOW  # Add APPWINDOW style
        windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
        # Change taskbar Icon:
        root.wm_withdraw()  # Hide the window briefly
        root.after(10, lambda: root.wm_deiconify())  # Then show it again
    except Exception as e:
        print(f"Error setting window style?: {e}")


root = tk.Tk()

#/////// INITIAL Formating ///////
#Remove border
root.overrideredirect(1)
#root.wm_state("zoomed")
#fullscreen application(disable for now)
#Screen Size
root.geometry("575x375")
#center the screen
centerWindow(root)
#title the window
root.title("Ogre Encryption Software")
# ////////////////////////////////

#/////// *CSS* or Images ///////////
#Make the CSS equivalent of python
canvas = tk.Canvas(root, width=574, height=374)  # Create canvas
canvas.pack(fill="both", expand=True)
#Background image
backGrnd = tk.PhotoImage(file = "wall.png")
lbl = tk.Label(image = backGrnd).pack()
canvas.create_image(0, 0, anchor="nw", image=backGrnd)
#logo image
upImage = Image.open("OgreEncrypt.png")
OgreEn = ImageTk.PhotoImage(upImage)
canvas.create_image(8, 10, anchor = "nw", image=OgreEn)
#OgreFace
upperImage = Image.open("ogreFace.png")
cutie = ImageTk.PhotoImage(upperImage)
canvas.create_image(390,150, anchor = "nw" , image=cutie)
#add input to canvas
Input = tk.Entry(canvas, width=30,)
canvas.create_window(287, 200, window=Input)
submit_button = tk.Button(canvas, text="Decend", command=getInput)
canvas.create_window(287, 250, window=submit_button)
#make ogre face logo
root.iconphoto(False,cutie)
#//////////////////////////////////

#FORCE WINDOW IN TASKBAR
root.after(10, lambda: setAppwindow(root))


root.mainloop()
