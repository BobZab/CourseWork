import tkinter as tk
from PIL import Image, ImageTk
import webbrowser
from ctypes import windll

# List of inputs
attempts = []

GWL_EXSTYLE = -20
WS_EX_APPWINDOW = 0x00040000
WS_EX_TOOLWINDOW = 0x00000080

# Force the window to the middle of the screen
def centerWindow(window):
    window.update_idletasks()
    width = window.winfo_width()
    height = window.winfo_height()
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    x = (screen_width // 2) - (width // 2)
    y = (screen_height // 2) - (height // 2)
    window.geometry('{}x{}+{}+{}'.format(width, height, x, y))

def getInput():
    userInput = Input.get()
    attempts.append(userInput)
    print("user input: ", userInput)
    print("Previous Attempts: ", attempts)
    Input.delete(0, tk.END)
    openTab(userInput) #call openTab here

# Force window to actually appear
def setAppwindow(root):
    try:
        hwnd = windll.user32.GetParent(root.winfo_id())
        style = windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
        style = style & ~WS_EX_TOOLWINDOW
        style = style | WS_EX_APPWINDOW
        windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
        root.wm_withdraw()
        root.after(10, lambda: root.wm_deiconify())
    except Exception as e:
        print(f"Error setting window style?: {e}")

def openTab(user_input): #pass the input
    if user_input == "IDK":
        webbrowser.open_new_tab("https://imgur.com/a/vhs-code-pOzbyJo")

root = tk.Tk()

# Initial Formatting
root.overrideredirect(1)
root.geometry("575x375")
centerWindow(root)
root.title("Ogre Encryption Software")

# *CSS* or Images
canvas = tk.Canvas(root, width=574, height=374)
canvas.pack(fill="both", expand=True)
backGrnd = tk.PhotoImage(file="wall.png")
canvas.create_image(0, 0, anchor="nw", image=backGrnd)
upImage = Image.open("OgreEncrypt.png")
OgreEn = ImageTk.PhotoImage(upImage)
canvas.create_image(8, 10, anchor="nw", image=OgreEn)
upperImage = Image.open("ogreFace.png")
cutie = ImageTk.PhotoImage(upperImage)
canvas.create_image(390, 150, anchor="nw", image=cutie)
Input = tk.Entry(canvas, width=30)
canvas.create_window(287, 200, window=Input)
submit_button = tk.Button(canvas, text="Decend", command=getInput) # Corrected here
canvas.create_window(287, 250, window=submit_button)
root.iconphoto(False, cutie)

# FORCE WINDOW IN TASKBAR
root.after(10, lambda: setAppwindow(root))

root.mainloop()
