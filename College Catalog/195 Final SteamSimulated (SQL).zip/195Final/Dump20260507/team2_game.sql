-- MySQL dump 10.13  Distrib 8.0.45, for macos15 (arm64)
--
-- Host: radyweb.wsc.western.edu    Database: team2
-- ------------------------------------------------------
-- Server version	5.5.5-10.3.39-MariaDB-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `game`
--

DROP TABLE IF EXISTS `game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game` (
  `game_ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `description` varchar(200) NOT NULL,
  `web_link` varchar(100) NOT NULL,
  `banner` varchar(30) NOT NULL,
  `price` decimal(4,2) NOT NULL CHECK (`price` >= 0),
  `sale_price` decimal(4,2) DEFAULT NULL CHECK (`sale_price` >= 0 and `sale_price` <= `price`),
  `dlc_parent_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`game_ID`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `web_link` (`web_link`),
  KEY `dlc_parent_ID` (`dlc_parent_ID`),
  CONSTRAINT `game_ibfk_1` FOREIGN KEY (`dlc_parent_ID`) REFERENCES `game` (`game_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game`
--

LOCK TABLES `game` WRITE;
/*!40000 ALTER TABLE `game` DISABLE KEYS */;
INSERT INTO `game` VALUES (1,'Hotline Miami 2','A top down bullethell.','https://store.steampowered.com/agecheck/app/274170/','hotline_banneer.png',14.99,NULL,NULL),(2,'Tunic','A puzzle game, featuring a fox charecter','https://store.steampowered.com/app/553420/TUNIC/','Fox_friend.png',29.99,NULL,NULL),(3,'Manifold Garden','First Person Puzzle game','https://store.steampowered.com/app/473950/Manifold_Garden/','mystry_building.png',19.99,NULL,NULL),(4,'Radii','A challenging platformer.','https://store.steampowered.com/app/2063700/Radii/','ball_banner.png',0.00,NULL,NULL),(5,'Blaze','a 3rd person over the shoulder action adventure game','https://store.steampowered.com/app/1287940/Blaze/','logo_blaze.png',0.00,NULL,NULL),(6,'Team Fortreess 2','First person shooter with nine distinct classes provide a broad range of tactical abilities and personalities.','https://store.steampowered.com/app/440/Team_Fortress_2/','the_goat.jpg',0.00,NULL,NULL),(7,'Counter Strike','Play the world\'s number 1 online action game, first person shooter.','https://store.steampowered.com/app/10/CounterStrike/','first_banner.raw',9.99,NULL,NULL),(8,'Magic: The Gathering Arena','Online PvP Card game, to drain your 401k.','https://store.steampowered.com/app/2141910/Magic_The_Gathering_Arena/','mtg_rocks.png',0.00,NULL,NULL),(9,'Inscryption','Inscryption is an inky black card-based odyssey that blends the deckbuilding roguelike, escape-room style puzzles, and psychological horror into a blood-laced smoothie.','https://store.steampowered.com/app/1092790/Inscryption/','leshy.png',19.99,NULL,NULL),(10,'Risk of Rain 2','Third person PvE rougelike, on an alien planet.','https://store.steampowered.com/app/632360/Risk_of_Rain_2/','hopoo.png',24.99,NULL,NULL),(11,'Brutal Legend','The best video game, with jack black.','https://store.steampowered.com/app/225260/Brutal_Legend/','true_rock.jpg',14.99,NULL,NULL),(12,'Frog Fractions','Frog Tower Defense','https://store.steampowered.com/app/1194840/Frog_Fractions_Game_of_the_Decade_Edition/','mystery.png',0.00,NULL,NULL),(13,'Skyrim','a open-world fantasy epic,','https://store.steampowered.com/app/72850/The_Elder_Scrolls_V_Skyrim/','dovaking.png',19.99,NULL,NULL),(18,'Frog Fractions 4','Experience a day in the life of a frog who is wearing a hat!','https://store.steampowered.com/app/1366091/Frog_Fractions_GotDE__Hops_Iconic_Cap/','hat.png',9.99,NULL,12),(19,'Ror2 Survivors of the Void','The Gateway to The Void has opened!','https://store.steampowered.com/app/1607890/Risk_of_Rain_2_Survivors_of_the_Void/','void_people.png',14.99,NULL,10);
/*!40000 ALTER TABLE `game` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-07 18:57:43
