-- MySQL dump 10.13  Distrib 8.0.45, for macos15 (arm64)
--
-- Host: radyweb.wsc.western.edu    Database: team2
-- ------------------------------------------------------
-- Server version	5.5.5-10.3.39-MariaDB-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gift`
--

DROP TABLE IF EXISTS `gift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gift` (
  `gift_ID` int(11) NOT NULL AUTO_INCREMENT,
  `message` char(200) NOT NULL,
  `arrival_date` date NOT NULL DEFAULT curdate(),
  `arrival_time` time NOT NULL DEFAULT curtime(),
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `inventory` tinyint(1) NOT NULL DEFAULT 0,
  `game_ID` int(11) NOT NULL,
  `user_ID` int(11) NOT NULL,
  `friend_ID` int(11) NOT NULL,
  PRIMARY KEY (`gift_ID`),
  KEY `game_ID` (`game_ID`),
  KEY `user_ID` (`user_ID`,`friend_ID`),
  CONSTRAINT `gift_ibfk_1` FOREIGN KEY (`game_ID`) REFERENCES `game` (`game_ID`),
  CONSTRAINT `gift_ibfk_2` FOREIGN KEY (`user_ID`, `friend_ID`) REFERENCES `friendship` (`user_ID`, `friend_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift`
--

LOCK TABLES `gift` WRITE;
/*!40000 ALTER TABLE `gift` DISABLE KEYS */;
INSERT INTO `gift` VALUES (16,'Happy Birthday!','2026-04-04','23:59:59',0,0,1,30,404884909),(17,'Hey man, I dont owe you anymore.','2026-03-21','13:47:38',0,0,3,32,404883908),(18,'Message','2025-09-22','11:18:45',0,0,10,34,404883910),(19,'here you go','2026-01-05','09:28:26',1,0,11,35,404883908),(20,'Dearest friend, here is a gift for you.','2025-11-09','10:23:45',0,0,13,34,404883914),(21,'Thanks','2025-10-05','15:45:30',0,1,19,37,404884909),(22,'I hate you','2026-04-04','23:59:59',0,0,18,35,404883908),(23,'<333','2026-04-04','23:59:59',0,1,13,34,404883914),(24,'I sent you a game please respond','2025-03-04','05:45:10',0,0,11,35,404884909),(25,'Please play this.','2025-04-03','22:59:57',0,0,9,31,404883910),(26,'Merry Christmas','2025-12-31','16:41:22',1,0,7,39,404883908),(27,'Good Morning','2026-01-12','06:54:19',0,0,10,41,404883912),(28,'Hows it Goin?','2024-01-04','11:24:36',0,0,6,33,867530999),(29,'ahoy there matey, play this ere game.','2024-06-27','13:56:20',0,0,2,42,405883908),(30,'Goodbye','2024-05-20','11:47:51',0,1,18,35,404883908);
/*!40000 ALTER TABLE `gift` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-07 18:57:42
