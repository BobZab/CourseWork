-- MySQL dump 10.13  Distrib 8.0.45, for macos15 (arm64)
--
-- Host: radyweb.wsc.western.edu    Database: team2
-- ------------------------------------------------------
-- Server version	5.5.5-10.3.39-MariaDB-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sale`
--

DROP TABLE IF EXISTS `sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sale` (
  `sale_ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `web_link` varchar(255) NOT NULL,
  `company` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL CHECK (`end_date` > `start_date`),
  PRIMARY KEY (`sale_ID`),
  UNIQUE KEY `web_link` (`web_link`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale`
--

LOCK TABLES `sale` WRITE;
/*!40000 ALTER TABLE `sale` DISABLE KEYS */;
INSERT INTO `sale` VALUES (1,'Steam Summer Sale','https://store.steampowered.com/sale/summer-sale-2025','Valve','2025-06-26','2025-07-10'),(2,'Steam Winter Sale','https://store.steampowered.com/sale/winter-sale-2025','Valve','2025-12-18','2026-01-01'),(3,'Steam Fall Sale','https://store.steampowered.com/sale/autumn-sale-2025','Valve','2025-11-26','2025-12-03'),(4,'Steam Spring Sale','https://store.steampowered.com/sale/spring-sale-2025','Valve','2025-03-13','2025-03-20'),(5,'Devolver Publisher Sale','https://store.steampowered.com/publisher/devolverdigital','Devolver Digital','2025-01-15','2025-01-22'),(6,'Twinbeard Collection','https://store.steampowered.com/search/?publisher=Twinbeard','Twinbeard.Inc','2025-08-12','2025-08-19'),(7,'Finji Studio Sale','https://store.steampowered.com/publisher/finji','isometricorp games','2025-04-10','2025-04-17'),(8,'Manifold Garden Sale','https://store.steampowered.com/app/1067530/Manifold_Garden/','William Chyr Studio','2025-10-18','2025-10-25'),(9,'Magic: Spellslingers Event','https://store.steampowered.com/app/1251040/Magic_Spellslingers/','Wizards of the Coast LLC','2025-02-14','2025-02-28'),(10,'NBA 2K Season Launch','https://store.steampowered.com/app/2324650/NBA_2K25/','2k','2025-09-05','2025-10-05'),(11,'Double Fine Anniversary','https://store.steampowered.com/publisher/doublefine','Double Fine Productions','2025-07-22','2025-07-29'),(12,'Xbox Game Studios Sale','https://store.steampowered.com/publisher/XboxGameStudios','Xbox Game Studios','2025-06-11','2025-06-18'),(13,'QuakeCon Bethesda Sale','https://store.steampowered.com/publisher/bethesda','Bethesda','2025-08-07','2025-08-10'),(14,'Risk of Rain Day','https://store.steampowered.com/app/1091500/Risk_of_Rain_2/','Hopoo','2025-11-08','2025-11-15'),(15,'Gearbox Publishing Sale','https://store.steampowered.com/publisher/gearbox','Gearbox','2025-05-13','2025-05-20'),(16,'Inscryption Mystery Event','https://store.steampowered.com/app/1092790/Inscryption/','Daniel Mullins Games','2025-10-31','2025-11-07');
/*!40000 ALTER TABLE `sale` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-07 18:57:43
