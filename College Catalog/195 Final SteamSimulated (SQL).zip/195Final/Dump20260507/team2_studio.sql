-- MySQL dump 10.13  Distrib 8.0.45, for macos15 (arm64)
--
-- Host: radyweb.wsc.western.edu    Database: team2
-- ------------------------------------------------------
-- Server version	5.5.5-10.3.39-MariaDB-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `studio`
--

DROP TABLE IF EXISTS `studio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `studio` (
  `studio_ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `followers` int(11) NOT NULL DEFAULT 0 CHECK (`followers` >= 0),
  PRIMARY KEY (`studio_ID`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studio`
--

LOCK TABLES `studio` WRITE;
/*!40000 ALTER TABLE `studio` DISABLE KEYS */;
INSERT INTO `studio` VALUES (46,'Devolver Digital','support@devolverdigital.com','Publishers of classic titles.','Devolver.png',434420),(47,'Twinbeard.Inc','find jim stormdancer','creator of the frog fractions universe','stormdance.png',7109),(48,'isometricorp games','support@finji.co','Creators of TUNIC, out now everywhere.','fox_polygon.png',7000),(49,'William Chyr Studio','chyr@williamchyr.com','William Chyr Studio\'s debut game Manifold Garden is now available.','manifold.png',1933),(50,'WormyMaple Games','none','None','blank',0),(51,'Charcoal Games','none',' None','fire_emblem.png',0),(52,'Valve','https://help.steampowered.com','websites','steam_valve.png',952881),(53,'Wizards of the Coast LLC ','https://support.wizards.com/hc/en-us/requests/new','Creators of Magic: The Gathering','mtgLogo.png',37300),(54,'2k','email','“2K develops and publishes critically-acclaimed franchises such as BioShock, Borderlands, Mafia, Sid Meier’s Civilization, XCOM, WWE 2K, and NBA 2K.”','stealuserdata.jpg',446520),(55,'Double Fine Productions','@doublefine.com','Double Fine Productions is a San Francisco-based game developer founded by industry legend Tim Schafer, and is part of Xbox Game Studios.','logo',72849),(56,'Xbox Game Studios','https://support.microsoft.com/en-us/contactus','Xbox Game Studios is the video game production wing for Microsoft','xboxlogo.png',847909),(57,'Bethesda','  info@bethsoft.com','“”','softworks.png',1247164),(58,'Hopoo',' hopoo@hopoogames.com','Hopoo Games was founded in 2012 by Duncan Drummond and Paul Morse with a creative goal – to make games we’d actually want to play.','hopoo.png',21000),(59,'Gearbox','https://www.gearboxpublishing.com/','Official account for Gearbox Entertainment.','gearboxLogo.png',1100000),(60,'Daniel Mullins Games','support@danielmullinsgames.com','Daniel Mullins Games','dansLogo.png',38100);
/*!40000 ALTER TABLE `studio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-07 18:57:41
