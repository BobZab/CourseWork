-- MySQL dump 10.13  Distrib 8.0.45, for macos15 (arm64)
--
-- Host: radyweb.wsc.western.edu    Database: team2
-- ------------------------------------------------------
-- Server version	5.5.5-10.3.39-MariaDB-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_ID` int(11) NOT NULL AUTO_INCREMENT,
  `friend_ID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `profile_icon` varchar(255) DEFAULT NULL,
  `join_date` date NOT NULL,
  `vac_banned` tinyint(1) NOT NULL DEFAULT 0,
  `steam_family_ID` int(11) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_ID`,`friend_ID`),
  UNIQUE KEY `user_ID` (`user_ID`),
  UNIQUE KEY `friend_ID` (`friend_ID`),
  KEY `steam_family_ID` (`steam_family_ID`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`steam_family_ID`) REFERENCES `steam_family` (`steam_family_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (30,404883908,'EggFuu','egg.png','2017-04-06',0,1,'Los Cocos'),(31,404884909,'BlueRedOrange','egg.png','2017-04-06',0,NULL,'I Don\'t have a steam profile'),(32,404883910,'WormyCanadaTree','red.png','2017-04-06',0,NULL,'Check out Radii'),(33,404883911,'Chicken','Kernal.png','2017-04-06',0,NULL,'KFC'),(34,404883912,'D3t04r','chicken.png','2017-04-06',0,NULL,'The Goat'),(35,404883913,'DarkMagicEuler','yugioh.png','2002-04-06',0,NULL,'Magic: The Gathering'),(36,404883914,'Nova','skull.png','2017-04-06',0,NULL,'Thanks'),(37,405883908,'SeqOfNam','portal.png','2017-04-06',0,1,NULL),(38,676767676,'Auhsten','default.png','2017-04-06',0,NULL,'Wait wher do i put a description?'),(39,420420420,'HuuFoo','oneeye.png','2000-04-06',0,NULL,'20 year vet on here'),(40,867530999,'Seagul','eagul.png','2017-04-06',0,NULL,'Squak'),(41,666666666,'Saint_Paul','lilGuy.png','2017-04-06',1,NULL,'Im Depressed'),(42,404883920,'JSmith','astronaut.png','2017-04-06',0,1,'Family Guy'),(43,404883921,'FlushedPuu72','redDead2.png','2017-04-06',0,NULL,'I know Young Thug'),(44,404883922,'Naysayer','JonathinBlow.png','2017-04-06',0,NULL,'Braid'),(45,304883908,'Sony','ps5.png','2017-04-06',1,NULL,'Not spying on Valve');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-07 18:57:42
