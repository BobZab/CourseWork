
use team2;

DROP PROCEDURE IF EXISTS getLibrary;
DELIMITER //
CREATE PROCEDURE getLibrary(
	user_ID INT
)
BEGIN
	SELECT game.game_ID, game.name
	FROM user
    LEFT JOIN user_game
    ON user_game.user_ID = user.user_ID
    LEFT JOIN game
    ON user_game.game_ID = game.game_ID
	WHERE user.user_ID = user_ID;
END//
DELIMITER ;


CALL getLibrary((SELECT user_ID FROM user WHERE user.name = "EggFuu"));

 


DROP PROCEDURE IF EXISTS getFriendList;
DELIMITER //
CREATE PROCEDURE getFriendList(
	user_ID INT
)
BEGIN
	SELECT *
	FROM user
	LEFT JOIN friendship
	ON user.user_ID = friendship.user_ID
	LEFT JOIN user as friend
	ON friendship.friend_ID = friend.friend_ID
	WHERE user.user_ID = user_ID;
END//
DELIMITER ;

CALL getFriendList((SELECT user_ID FROM user WHERE user.name = "EggFuu"));










