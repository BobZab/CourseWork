USE team2;

DROP TABLE IF EXISTS user_game;
DROP TABLE IF EXISTS friendship;

DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS gift;
DROP TABLE IF EXISTS game_developer;
DROP TABLE IF EXISTS game_publisher;
DROP TABLE IF EXISTS game_tag;
DROP TABLE IF EXISTS game_sale;

DROP TABLE IF EXISTS game;
DROP TABLE IF EXISTS steam_family;
DROP TABLE IF EXISTS studio;
DROP TABLE IF EXISTS sale;
DROP TABLE IF EXISTS tag;




CREATE TABLE game(
	game_ID int primary key auto_increment,
    `name` varchar(30) UNIQUE NOT NULL,
    description varchar(200) NOT NULL,
    web_link varchar(100) UNIQUE NOT NULL,
    banner varchar(30) NOT NULL,
    price DECIMAL(4, 2) NOT NULL CHECK(price >= 0),
    sale_price DECIMAL(4, 2) DEFAULT NULL CHECK(sale_price >= 0 AND sale_price <= price),
    dlc_parent_ID INT DEFAULT NULL,
    FOREIGN KEY (dlc_parent_ID) REFERENCES game(game_ID)
);
CREATE TABLE steam_family(
	steam_family_ID int primary key auto_increment,
    name varchar(30) NOT NULL,
    start_date DATE NOT NULL,
    reached_limit tinyint(1) DEFAULT 0 NOT NULL
);
CREATE TABLE studio(
	studio_ID int primary key auto_increment,
    `name` varchar(30) UNIQUE DEFAULT NULL,
    email varchar(30) NOT NULL,
    description varchar(200) DEFAULT NULL,
    logo varchar(30) DEFAULT NULL,
    followers int DEFAULT(0) NOT NULL CHECK(followers >= 0)
);
CREATE TABLE sale(
	sale_ID int primary key auto_increment,
    `name` varchar(30) NOT NULL,
    web_link varchar(60) NOT NULL UNIQUE,
    company varchar(30) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL CHECK(end_date > start_date)
);
CREATE TABLE tag(
	tag_ID int primary key auto_increment,
    `name` varchar(20) unique NOT NULL
);


CREATE TABLE user(
	user_ID int unique AUTO_INCREMENT NOT NULL,
    friend_ID int unique NOT NULL,
    `name` varchar(30) NOT NULL,
    friend_code int unique NOT NULL,
    profile_icon varchar(30) DEFAULT NULL,
    join_date DATE NOT NULL,
    vac_banned tinyint(1) DEFAULT(0) NOT NULL,
    steam_family_ID int DEFAULT NULL,
    PRIMARY KEY (user_ID, friend_ID),
    FOREIGN KEY (steam_family_ID) REFERENCES steam_family(steam_family_ID)
);
CREATE TABLE gift(
	gift_ID int primary key auto_increment,
    message char(200) NOT NULL,
    arrival_date DATE DEFAULT (CURRENT_DATE) NOT NULL,
    arrival_time TIME DEFAULT (CURRENT_TIME) NOT NULL,
    status TINYINT(1) DEFAULT(0) NOT NULL,
    inventory tinyint(1) DEFAULT(0) NOT NULL, 
    game_ID int NOT NULL,
    FOREIGN KEY (game_ID) REFERENCES game(game_ID)
);
CREATE TABLE game_developer(
	game_ID int not null,
    studio_ID int not null,
    primary key(game_ID, studio_ID),
    foreign key (game_ID) references game(game_ID),
    foreign key (studio_ID) references studio(studio_ID)
);
CREATE TABLE game_publisher(
	game_ID int not null,
    studio_ID int not null,
    primary key(game_ID, studio_ID),
    foreign key (game_ID) references game(game_ID),
    foreign key (studio_ID) references studio(studio_ID)
);
CREATE TABLE game_tag(
	game_ID int not null,
    tag_ID int not null,
    primary key(game_ID, tag_ID),
    foreign key (game_ID) references game(game_ID),
    foreign key (tag_ID) references tag(tag_ID)
);
CREATE TABLE game_sale(
	game_ID int not null,
    sale_ID int not null,
    primary key (game_ID, sale_ID),
    foreign key (game_ID) references game(game_ID),
    foreign key (sale_ID) references sale(sale_ID)
);


CREATE TABLE user_game(
	game_ID int not null,
    user_ID int not null,
    primary key (game_ID, user_ID),
    foreign key (game_ID) references game(game_ID),
    foreign key (user_ID) references user(user_ID)
);
CREATE TABLE friendship(
	user_ID int not null,
    friend_ID int not null,
    gift_ID int default null,
    PRIMARY KEY (user_ID, friend_ID, gift_ID),
    foreign key (user_ID) references user(user_ID),
	foreign key (friend_ID) references user(friend_ID),
	foreign key (gift_ID) references gift(gift_ID)
);

