USE team2;

ALTER TABLE user
DROP COLUMN friend_code;

ALTER TABLE user
ADD COLUMN `description` VARCHAR(100);

DROP TABLE IF EXISTS friendship;
DROP TABLE IF EXISTS gift;

CREATE TABLE friendship(
	user_ID int not null,
    friend_ID int not null,
    PRIMARY KEY (user_ID, friend_ID),
    foreign key (user_ID) references user(user_ID),
	foreign key (friend_ID) references user(friend_ID)
);

CREATE TABLE gift(
	gift_ID int primary key auto_increment,
    message char(200) NOT NULL,
    arrival_date DATE DEFAULT (CURRENT_DATE) NOT NULL,
    arrival_time TIME DEFAULT (CURRENT_TIME) NOT NULL,
    status TINYINT(1) DEFAULT(0) NOT NULL,
    inventory tinyint(1) DEFAULT(0) NOT NULL, 
    game_ID int NOT NULL,
    user_ID int NOT NULL,
    friend_ID int NOT NULL,
    FOREIGN KEY (game_ID) REFERENCES game(game_ID),
    FOREIGN KEY (user_ID, friend_ID) REFERENCES friendship(user_ID, friend_ID)
);
