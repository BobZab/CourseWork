/*
#Insert Into game(name, description,web_link,banner,price,sale_price,dlc_parent_ID)
#VALUES

#("name", "description","web_link","banner",10, null, null),
("Hotline Miami 2", "A top down bullethell.","https://store.steampowered.com/agecheck/app/274170/","hotline_banneer.png",14.99, null, null),
("Tunic", "A puzzle game, featuring a fox charecter","https://store.steampowered.com/app/553420/TUNIC/","Fox_friend.png",29.99, null, null),
("Manifold Garden", "First Person Puzzle game","https://store.steampowered.com/app/473950/Manifold_Garden/","mystry_building.png",19.99, null, null),
("Radii", "A challenging platformer.","https://store.steampowered.com/app/2063700/Radii/","ball_banner.png",0, null, null),
("Blaze", "a 3rd person over the shoulder action adventure game","https://store.steampowered.com/app/1287940/Blaze/","logo_blaze.png",0, null, null),
("Team Fortreess 2", "First person shooter with nine distinct classes provide a broad range of tactical abilities and personalities.","https://store.steampowered.com/app/440/Team_Fortress_2/","the_goat.jpg",0, null, null),
("Counter Strike", "Play the world's number 1 online action game, first person shooter.","https://store.steampowered.com/app/10/CounterStrike/","first_banner.raw",9.99, null, null),
("Magic: The Gathering Arena", "Online PvP Card game, to drain your 401k.","https://store.steampowered.com/app/2141910/Magic_The_Gathering_Arena/","mtg_rocks.png",0, null, null),
("Inscryption", "Inscryption is an inky black card-based odyssey that blends the deckbuilding roguelike, escape-room style puzzles, and psychological horror into a blood-laced smoothie.","https://store.steampowered.com/app/1092790/Inscryption/","leshy.png",19.99, null, null),
("Risk of Rain 2", "Third person PvE rougelike, on an alien planet.","https://store.steampowered.com/app/632360/Risk_of_Rain_2/","hopoo.png",24.99, null, null),
("Brutal Legend", "The best video game, with jack black.","https://store.steampowered.com/app/225260/Brutal_Legend/","true_rock.jpg",14.99, null, null),
("Frog Fractions", "Frog Tower Defense","https://store.steampowered.com/app/1194840/Frog_Fractions_Game_of_the_Decade_Edition/","mystery.png",0, null, null),
("Skyrim", "a open-world fantasy epic,","https://store.steampowered.com/app/72850/The_Elder_Scrolls_V_Skyrim/","dovaking.png",19.99, null, null)
("Frog Fractions 4", "Experience a day in the life of a frog who is wearing a hat!","https://store.steampowered.com/app/1366091/Frog_Fractions_GotDE__Hops_Iconic_Cap/","hat.png",9.99, null, null),
("Ror2 Survivors of the Void", "The Gateway to The Void has opened!","https://store.steampowered.com/app/1607890/Risk_of_Rain_2_Survivors_of_the_Void/","void_people.png",14.99, null, null);*/

/*
INSERT Into steam_family(name, start_date, reached_limit)
VALUES
("Smiths", current_date(), 0);*/



/*
Insert into studio(name, email, description, logo, followers)
VALUES
("Devolver Digital", "support@devolverdigital.com", "Publishers of classic titles.", "Devolver.png", 434420),
("Twinbeard.Inc", "find jim stormdancer", "creator of the frog fractions universe", "stormdance.png", 7109),
("isometricorp games", "support@finji.co", "Creators of TUNIC, out now everywhere.", "fox_polygon.png", 7000),
("William Chyr Studio", "chyr@williamchyr.com", "William Chyr Studio's debut game Manifold Garden is now available.", "manifold.png", 1933),
("WormyMaple Games", "none", "None", "blank", 0),
("Charcoal Games", "none", " None", "fire_emblem.png", 0),
("Valve", "https://help.steampowered.com", "websites", "steam_valve.png", 952881),
("Wizards of the Coast LLC ", "https://support.wizards.com/hc/en-us/requests/new", "Creators of Magic: The Gathering", "mtgLogo.png", 37300),
("2k", "email", "“2K develops and publishes critically-acclaimed franchises such as BioShock, Borderlands, Mafia, Sid Meier’s Civilization, XCOM, WWE 2K, and NBA 2K.”", "stealuserdata.jpg", 446520),
("Double Fine Productions", "@doublefine.com", "Double Fine Productions is a San Francisco-based game developer founded by industry legend Tim Schafer, and is part of Xbox Game Studios.", "logo", 72849),
("Xbox Game Studios", "https://support.microsoft.com/en-us/contactus", "Xbox Game Studios is the video game production wing for Microsoft", "xboxlogo.png", 847909),
("Bethesda", "  info@bethsoft.com", "“”", "softworks.png", 1247164),
("Hopoo", " hopoo@hopoogames.com", "Hopoo Games was founded in 2012 by Duncan Drummond and Paul Morse with a creative goal – to make games we’d actually want to play.", "hopoo.png", 21000),
("Gearbox", "https://www.gearboxpublishing.com/", "Official account for Gearbox Entertainment.", "gearboxLogo.png", 1100000),
("Daniel Mullins Games", "support@danielmullinsgames.com", "Daniel Mullins Games", "dansLogo.png", 38100);


Insert Into sale (name, web_link, company, start_date, end_date)
VALUES
("Steam Summer Sale", "https://store.steampowered.com/sale/summer-sale-2025", "Valve", "2025-06-26", "2025-07-10"),
("Steam Winter Sale", "https://store.steampowered.com/sale/winter-sale-2025", "Valve", "2025-12-18", "2026-01-01"),
("Steam Fall Sale", "https://store.steampowered.com/sale/autumn-sale-2025", "Valve", "2025-11-26", "2025-12-03"),
("Steam Spring Sale", "https://store.steampowered.com/sale/spring-sale-2025", "Valve", "2025-03-13", "2025-03-20"),
("Devolver Publisher Sale", "https://store.steampowered.com/publisher/devolverdigital", "Devolver Digital", "2025-01-15", "2025-01-22"),
("Twinbeard Collection", "https://store.steampowered.com/search/?publisher=Twinbeard", "Twinbeard.Inc", "2025-08-12", "2025-08-19"),
("Finji Studio Sale", "https://store.steampowered.com/publisher/finji", "isometricorp games", "2025-04-10", "2025-04-17"),
("Manifold Garden Sale", "https://store.steampowered.com/app/1067530/Manifold_Garden/", "William Chyr Studio", "2025-10-18", "2025-10-25"),
("Magic: Spellslingers Event", "https://store.steampowered.com/app/1251040/Magic_Spellslingers/", "Wizards of the Coast LLC", "2025-02-14", "2025-02-28"),
("NBA 2K Season Launch", "https://store.steampowered.com/app/2324650/NBA_2K25/", "2k", "2025-09-05", "2025-10-05"),
("Double Fine Anniversary", "https://store.steampowered.com/publisher/doublefine", "Double Fine Productions", "2025-07-22", "2025-07-29"),
("Xbox Game Studios Sale", "https://store.steampowered.com/publisher/XboxGameStudios", "Xbox Game Studios", "2025-06-11", "2025-06-18"),
("QuakeCon Bethesda Sale", "https://store.steampowered.com/publisher/bethesda", "Bethesda", "2025-08-07", "2025-08-10"),
("Risk of Rain Day", "https://store.steampowered.com/app/1091500/Risk_of_Rain_2/", "Hopoo", "2025-11-08", "2025-11-15"),
("Gearbox Publishing Sale", "https://store.steampowered.com/publisher/gearbox", "Gearbox", "2025-05-13", "2025-05-20"),
("Inscryption Mystery Event", "https://store.steampowered.com/app/1092790/Inscryption/", "Daniel Mullins Games", "2025-10-31", "2025-11-07");

*/
/*
Insert into tag (`name`)
Values("RogueLike"),
("FPS"),
("Metroidvania"),
("Platformer"),
("RogueLite"),
("PVP"),
("Horror"),
("Dungeon Crawler"),
("Idle"),
("Strategy"),
("Turn-Based"),
("Puzzle"),
("Exploration"),
("Music"),
("2D"),
("3D");
*/

/*
****MODIFY DATES
Insert Into user (friend_ID, `name`, description, profile_icon, join_date, vac_banned, steam_family_ID)
values(404883908, "EggFuu","Los Cocos", "egg.png", "2017-04-06", 0, 1),
(404884909, "BlueRedOrange","I Don't have a steam profile",  "egg.png", "2017-04-06", 0, Null),
(404883910, "WormyCanadaTree","Check out Radii",  "red.png", "2017-04-06", 0, Null),
(404883911, "Chicken","KFC",  "Kernal.png", "2017-04-06", 0, Null),
(404883912, "D3t04r","The Goat",  "chicken.png", "2017-04-06", 0, Null),
(404883913, "DarkMagicEuler","Magic: The Gathering",  "yugioh.png", "2002-04-06", 0, Null),
(404883914, "Nova","Thanks",  "skull.png", "2017-04-06", 0, Null),
(405883908, "SeqOfNam", Null,  "portal.png", "2017-04-06", 0, 1),
(676767676, "Auhsten","Wait wher do i put a description?",  "default.png", "2017-04-06", 0, Null),
(420420420, "HuuFoo","20 year vet on here",  "oneeye.png", "2000-04-06", 0, Null),
(867530999, "Seagul","Squak",  "eagul.png", "2017-04-06", 0, Null),
(666666666, "Saint_Paul","Im Depressed",  "lilGuy.png", "2017-04-06", 1, Null),
(404883920, "JSmith","Family Guy",  "astronaut.png", "2017-04-06", 0, 1),
(404883921, "FlushedPuu72","I know Young Thug",  "redDead2.png", "2017-04-06", 0, Null),
(404883922, "Naysayer","Braid",  "JonathinBlow.png", "2017-04-06", 0, Null),
(304883908, "Sony","Not spying on Valve",  "ps5.png", "2017-04-06", 1, Null);
*/

/*
insert into gift (message, arrival_date, arrival_time, status, inventory, game_ID, user_ID, friend_ID)
Values("Happy Birthday!", "2026-04-04", "23:59:59", 0, 0, 1, 30, 404884909),
("Hey man, I dont owe you anymore.", "2026-03-21", "13:47:38", 0, 0, 3 , 32, 404883908),
("Message", "2025-09-22", "11:18:45", 0, 0, 10, 34, 404883910),
("here you go", "2026-01-05", "09:28:26", 1, 0, 11, 35, 404883908),
("Dearest friend, here is a gift for you.", "2025-11-09", "10:23:45", 0, 0, 13, 34, 404883914),
("Thanks", "2025-10-05", "15:45:30", 0, 1, 19, 37, 404884909),
("I hate you", "2026-04-04", "23:59:59", 0, 0, 18, 35, 404883908),
("<333", "2026-04-04", "23:59:59", 0, 1, 13, 34, 404883914),
("I sent you a game please respond", "2025-03-04", "05:45:10", 0, 0, 11, 35, 404884909),
("Please play this.", "2025-04-03", "22:59:57", 0, 0, 9, 31, 404883910),
("Merry Christmas", "2025-12-31", "16:41:22", 1, 0, 7, 39, 404883908),
("Good Morning", "2026-01-12", "06:54:19", 0, 0, 10,41, 404883912),#
("Hows it Goin?", "2024-01-04", "11:24:36", 0, 0, 6, 33, 867530999),
("ahoy there matey, play this ere game.", "2024-06-27", "13:56:20", 0, 0, 2, 42, 405883908),
("Goodbye", "2024-05-20", "11:47:51", 0, 1, 18, 35, 404883908);
*/


/*
#1-13 + (18,19 ),30-45
Insert into user_game (game_ID, user_ID)
Values
(1, 30),
(1, 31),
(2, 31),
(3, 31),
(3, 32),
(4, 32),
(5, 32),
(3, 33),
(3, 33),
(7, 33),
(9, 34),
(10, 35),
(18, 36),
(19, 37),
(12, 38),
(11, 39),
(12, 40),
(4, 41),
(5, 42),
(6, 43),
(7, 44),
(8, 45),
(9, 45),
(10, 45);

Insert Into friendship (user_id, friend_ID)
VALUES 
(34, 404883910), 
(34, 404883914), 
(37, 404884909),   
(39, 404883908);
*/

/*
insert into friendship (user_id, friend_ID)
Values(30,'404884909'), (31, '404883908'),
(30, '404883910'), (32, '404883908'),
(30, '404883913'), (35, '404883908'),
(31, '404883910'), (32, '404884909'),
(31, '404883913'), (35, '404884909'),
(32, '404883913'), (35, '404883910'),
(34, '404883908'), (30, '404883912'),
(36, '404883908'), (30, '404883914'),
(37, '404883908'), (30, '405883908'),
(37, '676767676'), (38, '405883908'),
(39, '404884909'), (30, '420420420'),
(42, '405883908'), (37, '404883920'),
(30, '666666666'), (41, '404883908'),
(41, '404883912'), (34, '666666666'),
(33, '404883912'), (34, '404883911'),
(40, '404883911'), (33, '867530999');
*/

/*
insert into game_developer (game_ID, studio_ID)
Values
(1, 46),
(2, 48),
(3, 49),
(4, 50),
(5, 51),
(6, 52),
(7, 52),
(8, 53),
(9, 60),
(10, 58),
(11, 55),
(12, 47),
(13, 57),
(18, 47),
(19, 58);
*/

/*
insert into game_publisher (game_ID, studio_ID)
Values
(1, 46),
(2, 48),
(9, 46),
(10, 59),
(11, 56),
(19, 59);
*/

/*
insert into game_tag(game_id, tag_id)
Values
(1, 15), (1, 4),
(2, 12), (2, 13),
(3, 12), (3, 16),
(4, 4),(4, 15),
(5, 16), (5, 13),
(6, 2),(6, 6),
(7, 2),(7, 6),
(8, 10), (8, 6),
(9, 1), (9, 7),
(10, 1), (10, 16),
(11, 14), (11, 16),
(12, 9), (12, 12),
(13, 13), (13, 16),
(18, 12),(18, 15),
(19, 5),(19, 16);
*/

/*
insert into game_sale (game_id, sale_id)
Values
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(2, 1),
(2, 2),
(2, 3),
(2, 4),
(2, 7),
(3, 1), 
(3, 2), 
(3, 3), 
(3, 4), 
(3, 8),
(6, 1), 
(6, 2), 
(6, 3), 
(6, 4),
(6, 12),
(7, 1),
(7, 2),
(7, 3),
(7, 4), 
(7, 12),
(8, 9),
(9, 1), 
(9, 2),
(9, 3),
(9, 4),
(9, 5),
(9, 16),
(10, 1),
(10, 2),
(10, 3),
(10, 4), 
(10, 14), 
(10, 15),
(11, 1), 
(11, 2), 
(11, 3),
(11, 4), 
(11, 11),
(11, 12),
(12, 6),
(13, 1),
(13, 2),
(13, 3),
(13, 4),
(13, 13),
(18, 6),
(19, 1),
(19, 2),
(19, 3),
(19, 4),
(19, 14),
(19, 15);
*/
