####Single table queries
#Q.1 Find all games that are over "$20" (steam price does this via 19.99)
select game_id, name, price
from game
Where price >= 19.99;

#Q.2 Find all sales in 2026.
select sale_id, name, web_link, start_date, end_date
from sale
Where end_date like "%2026%";

#Q.3 List all games by price from most to least expensive. (cannot be free games)
select game_id, name, price
from game
Where price > 0
order by price desc;

#Q.4 List all users who are part of a family
select name, user_id, steam_family_ID
from user
Where steam_family_ID is not null;

#Q.5 Find all indie studios on the platform(Less than 10000 Followers, but more than 100.)
select studio_id, name, followers
from studio
Where followers < 10000 and followers > 100;

########################################################################################### Multi Table queries
#Q.1 Get all games published by devolver digital
select game_id, name, price
from game
Where game_id in (
	select game_Id
    from game_publisher
    Where studio_id in (
		select studio_id
        from studio
        Where name = "Devolver Digital"
    )
);

#Q.2 List all games part of the Steam Winter Sale
select game_id, name, price
from game
where game_id in (
	select game_id
    from game_sale
    where sale_id in (
		select sale_id
        from sale
        where name = "Steam Winter Sale"
    )
);

#Q.3 Find all PvP games. (games tagged with PvP)
select game_id, name, description
from game
Where game_id in (
	select game_id
    from game_tag
    where tag_id in(
		select tag_id
        from tag
        where name = "PvP"
    )
);

#Q.4 Find all members from the Smiths Family
select user.name
from user
Inner Join steam_family
on user.steam_family_ID = steam_family.steam_family_ID
where steam_family.name = "Smiths";

#Q.5 Find all games collectivlly from the Smiths Family
select game_id, name
from game
Where game_id in (
	select game_id
    from user_game
    where user_id in (
		select user_id
        from user
        where steam_family_ID in(
			select steam_Family_id
            from steam_family
            Where name = "Smiths"
		)
    )
);